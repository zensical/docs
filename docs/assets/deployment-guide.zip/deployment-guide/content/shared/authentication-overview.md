Authentication controls access to Acme Platform workspaces and administrative
settings. Configure it before connecting production services.

!!! warning
    Protect administrator access according to your organization's policy.

    @if authentication = local
        Store local administrator credentials in your approved secret store.

@if deployment = self-hosted
    Keep the authentication settings with the server configuration so they can
    be restored with the host.
