!!! note "Security note"

    Audit logs record administrator actions. For example, a log
    entry might show "credential updated" with the administrator
    name and timestamp. Limit administrator access to people
    responsible for operating the platform.
