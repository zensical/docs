@use shared/notices/platform-security.md

!!! tip

    Decide who will administer the platform before configuring authentication. Administrator accounts can create workspaces,
    connect services, and manage other users.

![link example](../../docs/assets/acme-platform-topology.svg)