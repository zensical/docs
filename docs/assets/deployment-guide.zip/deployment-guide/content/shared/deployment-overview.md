@if deployment = cloud

    Acme Platform provides a managed control plane for connecting
    internal services and managing the people who operate them.

@elif deployment = self-hosted

    Acme Platform provides a control plane that your team runs on
    its own Linux host to connect internal services and manage
    their operators.

![Acme Platform topology]

Before deploying the service, [configure authentication]
for the administrators who will operate it.

[Acme Platform topology]: ../../docs/assets/acme-platform-topology.svg
[configure authentication]: ../../docs/authentication.md

@use shared/notices/platform-security.md
