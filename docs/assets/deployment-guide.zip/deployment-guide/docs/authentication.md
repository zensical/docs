# Configure authentication

@use shared/authentication-overview.md

@if authentication = single-sign-on
    Configure the SAML or OpenID Connect connection before inviting users.
    Test sign-in with an administrator account before making it available to
    the wider organization.
@elif authentication = local
    Create the first administrator account locally. Require a strong password
    and keep the recovery procedure available to the operations team.
