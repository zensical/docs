# Acme Platform deployment guide

This is a small Zensical project for exploring variant-aware documentation in
VS Code with Zensical Studio. It contains one deployment guide that supports
three deliverables:

- `cloud` — cloud deployment with single sign-on;
- `self-hosted` — self-hosted deployment with local authentication; and
- `self-hosted-sso` — self-hosted deployment with single sign-on.

## Open the project

1. Extract the archive.
2. Open the `deployment-guide` folder in VS Code.
3. Use Zensical Studio to browse the project and inspect the Markdown sources
   alongside `catalog.toml`.

The default variant is `cloud`. The catalog lists every supported value and
the assignments for each named deliverable.

## Explore the sources

- `docs/deployment.md` uses `@if` and `@elif` to provide deployment-specific
  instructions.
- `docs/authentication.md` selects single sign-on or local-authentication
  guidance.
- `docs/index.md` uses `@var{name}` to insert values from the active variant.
- `docs/deployment.md` includes `content/shared/deployment-overview.md`, which
  itself includes `content/shared/notices/platform-security.md`. This shows
  nested `@use` in a realistic guide.

To build or preview the directives, use Zensical Spark. From this folder, run:

```console
zensical build
ZENSICAL_VARIANT=self-hosted-sso zensical build --clean
```
